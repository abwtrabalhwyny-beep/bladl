<?php
$files=glob(__DIR__.'/data/*.json'); usort($files,fn($a,$b)=>filemtime($b)<=>filemtime($a));
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>الإدارة</title><link rel="stylesheet" href="assets/style.css"></head>
<body><div class="top"><strong>إدارة السجلات</strong><a href="index.php">نموذج جديد</a></div><main class="container"><div class="card"><h1>السجلات المحفوظة</h1>
<div class="table">
<?php foreach($files as $f): $d=json_decode(file_get_contents($f),true); ?>
<div class="record"><div><b><?=htmlspecialchars($d['name']??'بدون اسم')?></b><small><?=htmlspecialchars($d['created_at']??'')?></small></div><div class="rec-actions"><a href="view.php?id=<?=htmlspecialchars($d['id'])?>" target="_blank">عرض</a><button onclick="navigator.clipboard.writeText(location.origin+location.pathname.replace('admin.php','')+'view.php?id=<?=$d['id']?>')">نسخ الرابط</button><button onclick="if(confirm('حذف السجل؟'))location='delete.php?id=<?=$d['id']?>'">حذف</button></div></div>
<?php endforeach; if(!$files): ?><p class="muted">لا توجد سجلات.</p><?php endif; ?>
</div></div></main></body></html>