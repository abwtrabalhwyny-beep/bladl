<?php
header('Content-Type: application/json; charset=utf-8');
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit;}
$d=json_decode(file_get_contents('php://input'),true);
if(!is_array($d)){http_response_code(400);echo json_encode(['ok'=>false]);exit;}
$dir=__DIR__.'/data'; if(!is_dir($dir))mkdir($dir,0755,true);
$id=bin2hex(random_bytes(8));
$d['created_at']=date('c'); $d['id']=$id;
file_put_contents("$dir/$id.json",json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX);
$base=(isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'?'https':'http').'://'.$_SERVER['HTTP_HOST'].rtrim(dirname($_SERVER['SCRIPT_NAME']),'/');
echo json_encode(['ok'=>true,'url'=>$base.'/view.php?id='.$id,'id'=>$id],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
?>