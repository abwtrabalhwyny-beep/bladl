const ids=["authority","municipality","name","idno","gender","nationality","formno","job","issue","expiry","program","license","facility","facilityNo"];
const $=x=>document.getElementById(x);
function readFile(inp,cb){let f=inp.files[0];if(!f)return;let r=new FileReader();r.onload=()=>cb(r.result);r.readAsDataURL(f)}
function collect(){let d={};ids.forEach(i=>d[i]=$(i).value);d.photo=$("photo").src||"";d.logoRight=$("rPrev").src||"";d.logoLeft=$("lPrev").src||"";return d}
function clearAll(){if(!confirm("مسح البيانات؟"))return;ids.forEach(i=>$(i).value="");["photo","rPrev","lPrev"].forEach(i=>$(i).removeAttribute("src"));$("result").classList.add("hidden")}
$("photoFile").onchange=e=>readFile(e.target,s=>$("photo").src=s);
$("rFile").onchange=e=>readFile(e.target,s=>$("rPrev").src=s);
$("lFile").onchange=e=>readFile(e.target,s=>$("lPrev").src=s);
$("create").onclick=async()=>{let r=await fetch("save.php",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(collect())});let x=await r.json();if(x.ok){$("url").value=x.url;$("result").classList.remove("hidden")}else alert("تعذر الحفظ")};
$("local").onclick=()=>{localStorage.setItem("draft",JSON.stringify(collect()));alert("تم الحفظ على الجهاز")};
$("clear").onclick=clearAll;$("print").onclick=()=>window.print();
$("copy").onclick=async()=>{await navigator.clipboard.writeText($("url").value);alert("تم نسخ الرابط")};
