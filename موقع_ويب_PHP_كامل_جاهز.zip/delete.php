<?php
$id=$_GET['id']??'';
if(preg_match('/^[a-f0-9]{16}$/',$id)){ $f=__DIR__."/data/$id.json"; if(is_file($f))unlink($f); }
header('Location: admin.php'); exit;
?>