<?php
session_start();
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>نظام إدارة النماذج</title><link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="top"><strong>نظام إدارة النماذج</strong><a href="admin.php">إدارة السجلات</a></div>
<main class="container">
<div class="card">
<h1>إنشاء نموذج جديد</h1>
<p class="muted">أدخل البيانات ثم احفظ لإنشاء رابط مشاركة مستقل.</p>
<div class="media">
<div><img id="photo" class="photo" alt=""><label class="upload">إضافة صورة<input id="photoFile" type="file" accept="image/*"></label></div>
<div class="logos">
<label>الشعار الأيمن<img id="rPrev" class="logo"><span class="upload">إضافة<input id="rFile" type="file" accept="image/*"></span></label>
<label>الشعار الأيسر<img id="lPrev" class="logo"><span class="upload">إضافة<input id="lFile" type="file" accept="image/*"></span></label>
</div></div>
<section id="fields">
<?php
$f=['authority'=>'الجهة','municipality'=>'البلدية / القسم','name'=>'الاسم','idno'=>'رقم الهوية','gender'=>'الجنس','nationality'=>'الجنسية','formno'=>'رقم النموذج','job'=>'المهنة','issue'=>'تاريخ الإصدار','expiry'=>'تاريخ الانتهاء','program'=>'البرنامج / الدورة','license'=>'رقم الترخيص','facility'=>'اسم المنشأة','facilityNo'=>'رقم المنشأة'];
foreach($f as $id=>$label){
echo '<div class="field"><label>'.$label.'</label>';
if($id==='gender')echo '<select id="'.$id.'"><option value="">اختر</option><option>ذكر</option><option>أنثى</option></select>';
elseif($id==='issue'||$id==='expiry')echo '<input id="'.$id.'" type="date">';
else echo '<input id="'.$id.'" placeholder="اكتب '.$label.'">';
echo '</div>';
}
?>
</section>
<div class="actions">
<button class="primary" id="create">حفظ وإنشاء رابط</button><button id="local">حفظ على الجهاز</button><button id="clear">مسح</button><button id="print">طباعة</button>
</div>
<div id="result" class="result hidden"><b>رابط العرض:</b><input id="url" readonly><button id="copy">نسخ الرابط</button></div>
</div></main>
<script src="assets/app.js"></script>
</body></html>