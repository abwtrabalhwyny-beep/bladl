<?php
$id=$_GET['id']??'';
if(!preg_match('/^[a-f0-9]{16}$/',$id))exit('رابط غير صالح');
$file=__DIR__."/data/$id.json"; if(!is_file($file))exit('السجل غير موجود');
$d=json_decode(file_get_contents($file),true);
$labels=['authority'=>'الجهة','municipality'=>'البلدية / القسم','name'=>'الاسم','idno'=>'رقم الهوية','gender'=>'الجنس','nationality'=>'الجنسية','formno'=>'رقم النموذج','job'=>'المهنة','issue'=>'تاريخ الإصدار','expiry'=>'تاريخ الانتهاء','program'=>'البرنامج / الدورة','license'=>'رقم الترخيص','facility'=>'اسم المنشأة','facilityNo'=>'رقم المنشأة'];
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>عرض النموذج</title><link rel="stylesheet" href="assets/style.css"></head>
<body><main class="container"><div class="card">
<header class="view-head"><img src="<?=htmlspecialchars($d['logoRight']??'')?>"><h1>عرض النموذج</h1><img src="<?=htmlspecialchars($d['logoLeft']??'')?>"></header>
<?php if(!empty($d['photo'])): ?><div class="center"><img class="photo" src="<?=htmlspecialchars($d['photo'])?>"></div><?php endif; ?>
<div class="view">
<?php foreach($labels as $k=>$label): if(($d[$k]??'')!==''): ?><div><span><?=$label?></span><b><?=htmlspecialchars($d[$k])?></b></div><?php endif; endforeach; ?>
</div>
<button class="primary" onclick="print()">طباعة</button>
</div></main></body></html>